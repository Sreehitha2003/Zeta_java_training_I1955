package com.zeta.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/*
 * this is a model which has all the data from the given database
 */
@Getter
@Setter
@Data
public class GeneralDetails {
	@JsonProperty("page")
	private int page;
	@JsonProperty("per_page")
	private int per_page;
	@JsonProperty("total")
	private int total;
	@JsonProperty("total_page")
	private int total_page;
	@JsonProperty("data")
	//this is the list of all the data in the data array
	private List<AllData> data;
	@JsonProperty("support")
	private SupportData sd;
	//following are the getters and setter for the above
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getPer_page() {
		return per_page;
	}
	public void setPer_page(int per_page) {
		this.per_page = per_page;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getTotal_page() {
		return total_page;
	}
	public void setTotal_page(int total_page) {
		this.total_page = total_page;
	}
	public List<AllData> getData() {
		return data;
	}
	public void setData(List<AllData> data) {
		this.data = data;
	}
	public SupportData getSd() {
		return sd;
	}
	public void setSd(SupportData sd) {
		this.sd = sd;
	}
}
