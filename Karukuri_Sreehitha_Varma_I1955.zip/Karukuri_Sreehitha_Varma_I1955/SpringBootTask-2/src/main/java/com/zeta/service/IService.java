package com.zeta.service;

import com.zeta.model.AllData;
import com.zeta.model.DataSupport;
import com.zeta.model.GeneralDetails;

/*
 * this is the service interface for this application
 */

public interface IService {
	//this is an interface defining the method getdata which gives the data from database
	public GeneralDetails getdata();
	//this interface is the method get data by id for the specific data id
	public DataSupport getdatabyid(int id);
	//this interface is method which gives data by page id
	public GeneralDetails getByPage(int page);
}
