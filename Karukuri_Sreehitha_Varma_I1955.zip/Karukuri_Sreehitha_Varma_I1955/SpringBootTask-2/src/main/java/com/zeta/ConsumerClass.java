package com.zeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/*
 * this is a main class
 */
@SpringBootApplication
public class ConsumerClass {
	//this is the main function for the spring boot application which will run the spring application
	public static void main(String[] args) {
		SpringApplication.run(ConsumerClass.class, args);
	}
	@Bean
	//this offers template method based api for making http requests and acts as an repository
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}
}
