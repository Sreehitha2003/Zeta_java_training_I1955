package com.zeta.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * this is a model with combination of data array and support json
 */
public class DataSupport {
	@JsonProperty("data")
	private AllData data;
	@JsonProperty("support")
	private SupportData text;
	//these are the setters and getters for the above variables
	public AllData getData() {
		return data;
	}
	public void setData(AllData data) {
		this.data = data;
	}
	public SupportData getText() {
		return text;
	}
	public void setText(SupportData text) {
		this.text = text;
	}
}
