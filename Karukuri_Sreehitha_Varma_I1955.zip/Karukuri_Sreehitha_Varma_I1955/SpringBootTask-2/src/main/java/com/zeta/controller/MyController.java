package com.zeta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.model.AllData;
import com.zeta.model.DataSupport;
import com.zeta.model.GeneralDetails;
import com.zeta.service.IService;

@RestController
//this is a rest controller
public class MyController {
	@Autowired
	IService service;
	@RequestMapping(method = RequestMethod.GET, value = "/data", 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	//this method gives the data which includes support info and data along with the pages info
	//GET method is used, for constructing "/data"
	public GeneralDetails getdata()
	{
	return service.getdata();
	}
	@RequestMapping(method = RequestMethod.GET, value = "/data/{id}", 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	//this method gives the data of specific id in the database
	//GET method is used, for constructing "/data/{id}"
	public DataSupport getDataById(@PathVariable int id) {
		return service.getdatabyid(id);
	}
	@RequestMapping(value = "/data/page/{page}", method = RequestMethod.GET,
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	//this gives the data present in particular page
	//GET method is used, for constructing "/page/{page}"
	public GeneralDetails getByPage(@PathVariable int page) {
	return service.getByPage(page);
	}
}
