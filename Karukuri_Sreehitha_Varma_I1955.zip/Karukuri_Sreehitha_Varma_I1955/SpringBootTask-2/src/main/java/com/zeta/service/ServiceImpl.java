package com.zeta.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zeta.model.DataSupport;
import com.zeta.model.GeneralDetails;

/*
 * this is a service implementation class which implements the interfaces from IService
 */
@Service
public class ServiceImpl implements IService{
	
	//for automatic injection of beans of rest template we used this annotation
	@Autowired
	RestTemplate restTemplate;
	
	//this gives the data present in the specific url
	@Override
	public GeneralDetails getdata() {
		try {
			RestTemplate restTemplate = new RestTemplate();
			//to add user defined headers we did it using httpheaders
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET,entity,GeneralDetails.class);

			GeneralDetails dt=(GeneralDetails) response.getBody();
			return dt;
			} catch (Exception ex) {
			ex.printStackTrace();
			return null;
			}
	}
	
	//this function gives the data of the given id
	public DataSupport getdatabyid(int id) {
			String url="https://reqres.in/api/users/{id}";
			url=url.replace("{id}", String.valueOf(id));

			try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET,entity,DataSupport.class);

			System.out.println(response);
			DataSupport dt=(DataSupport) response.getBody();
			return dt;
			} catch (Exception ex) {
			ex.printStackTrace();
			return null;
			}
	}
	
	//this function gives the data present in a page
	public GeneralDetails getByPage(int page) {
		String url = "https://reqres.in/api/users?page={id}";
		url = url.replace("{id}", String.valueOf(page));
		try {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("user-agent",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET, entity, GeneralDetails.class);

		System.out.println(response);
		GeneralDetails dt = (GeneralDetails) response.getBody();
		return dt;
		} catch (Exception ex) {
		ex.printStackTrace();
		return null;
		}
		}

}
