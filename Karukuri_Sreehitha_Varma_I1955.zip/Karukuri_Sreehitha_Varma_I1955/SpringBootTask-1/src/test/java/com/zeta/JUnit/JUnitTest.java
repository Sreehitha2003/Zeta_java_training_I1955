package com.zeta.JUnit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zeta.dao.IDaoRepository;
import com.zeta.model.Loan;
import com.zeta.service.IMyService;

/*
 * here junit testing is done
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@FixMethodOrder()
public class JUnitTest {
	@Autowired
	private IDaoRepository repo;
	@Autowired
	private IMyService service;
	
	@Test
	@Order(1)
	//this is a unit test for testing the get all loan details where we checked it by using equals
	public void getLoanDetailsTest() {
		//List<Loan> list = repo.findAll();
		List<Loan> list = service.getLoanDetails();
		assertEquals(7,list.size());
	}
	
	@Test
	@Order(2)
	//this unit test is testing if the new loan is created or not by using not null
	public void addNewLoanTest(){
		Loan l = new Loan();
		l.setLoan_no(109);l.setAadhaar_no("123456789876");
		l.setFirstname("sree");l.setLastname("varma");
		l.setAmount(2344.90);l.setStartdate(new Date(2011-11-11));l.setTenure(2.7);
		//using repository also we can do the testing
		//repo.save(l);
		//assertNotNull(repo.findOne(109));
		assertNotNull(service.addNewLoan(l));
	}
	
	@Test
	@Order(3)
	//this unit test tests if we can get the record details by using getloanbyid
	public void getLoanByIdTest(){
		//Loan l = repo.findOne(107);
		Loan l = service.getLoanById(107);
		assertEquals(5.5,l.getTenure(),0.0);
	}
	
	@Test
	@Order(4)
	//this unit test tests if the updates on existing record is working or not
	public void updateLoanTest(){
		//Loan l = repo.findOne(104);
		Loan l = service.getLoanById(104);
		l.setAmount(2222.22);
		//repo.save(l);
		assertNotEquals(82000.91,l.getAmount());
	}
	
	@Test
	@Order(5)
	//this unit test is testing if the deleted id is deleted or not
	public void deleteLoanByIdTest(){
		//repo.delete(109);
		service.deleteLoanById(109);
		assertEquals(false,repo.exists(109));
	}
}
