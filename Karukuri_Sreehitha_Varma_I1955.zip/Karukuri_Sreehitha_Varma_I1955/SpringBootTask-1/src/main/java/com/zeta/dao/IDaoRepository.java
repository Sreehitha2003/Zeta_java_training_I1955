package com.zeta.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zeta.model.Loan;

/*
 * this is a dao repository which uses JpaRepository methods 
 */
@Repository
public interface IDaoRepository extends JpaRepository<Loan,Integer>{
}
