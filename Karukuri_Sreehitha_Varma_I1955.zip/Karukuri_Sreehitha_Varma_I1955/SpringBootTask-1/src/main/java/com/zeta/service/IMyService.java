package com.zeta.service;

import java.util.List;

import com.zeta.model.Loan;
/*
 * it is an interface with all the functions 
 */
public interface IMyService {
	//this interface will give the details about all the loan accounts
	public List<Loan> getLoanDetails();
	//this interface will give the loan account details of the given loan number
	public Loan getLoanById(int loanno);
	//this interface will create an new loan account details into the table
	public Loan addNewLoan(Loan loan);
	//this interface will update the existing loan account
	public Loan updateLoan(Loan loan);
	//this interface will delete the specific loan detail of particular id
	public void deleteLoanById(int loanno);
	//this interface will delete all the accounts from the database
	public void deleteAllLoans();

}
