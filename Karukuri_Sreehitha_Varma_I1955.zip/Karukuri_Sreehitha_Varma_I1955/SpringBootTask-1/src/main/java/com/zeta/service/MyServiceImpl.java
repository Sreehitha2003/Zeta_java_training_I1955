package com.zeta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.dao.IDaoRepository;
import com.zeta.model.Loan;

@Service
/*here the implementation of the service layer methods take place for the interface
*created in the IMyService
*/
public class MyServiceImpl implements IMyService {
	@Autowired
	IDaoRepository dao;
	//this method uses the dao repository pre-defined method findall to get all the tuples.
	public List<Loan> getLoanDetails() {
		return dao.findAll();
	};
	//this method uses the dao repository pre-defined method findone to get the specific tuple of given id.
	public Loan getLoanById(int loanno) {
		return dao.findOne(loanno);
	};
	//this method uses the dao repository pre-defined method save to add a new tuple into the database.
	public Loan addNewLoan(Loan loan) {
		dao.save(loan);
		return loan;
	};
	//this method uses the dao repository pre-defined method save by taking the updated data.
	public Loan updateLoan(Loan loan) {
		dao.save(loan);
		return loan;
	};
	//this method uses the dao repository pre-defined method delete to delete the specific record with the id.
	public void deleteLoanById(int loanno) {
		dao.delete(loanno);
	};
	//this method uses the dao repository pre-defined method deleteall to delete all the tuples.
	public void deleteAllLoans() {
		dao.deleteAll();
	};
}
