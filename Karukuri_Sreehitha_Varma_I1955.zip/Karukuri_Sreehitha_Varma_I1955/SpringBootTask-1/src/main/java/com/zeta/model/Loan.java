package com.zeta.model;


import java.sql.Date;

import javax.persistence.*;

/*
 * this class defines the model for the application
 */
@Table(name="loanaccount")
@Entity
//this defines a model named loan which has all the attributes of loan
public class Loan {
	@Id
	@Column
	//this is the primary key loan number attribute
	private int loan_no;
	@Column
	//this is aadhaar number attribute with data type string
	private String aadhaar_no;
	@Column
	//this is first name attribute with data type string
	private String firstname;
	@Column
	//this is last name attribute with data type string
	private String lastname;
	@Column
	//this is amount attribute with data type double
	private double amount;
	@Column
	//this is start date attribute with data type date
	private Date startdate;
	@Column
	//this is tenure attribute with data type double
	private double tenure;
	// the following are the getters and setters for above attributes
	public int getLoan_no() {
		return loan_no;
	}

	public void setLoan_no(int loan_no) {
		this.loan_no = loan_no;
	}

	public String getAadhaar_no() {
		return aadhaar_no;
	}

	public void setAadhaar_no(String aadhaar_no) {
		this.aadhaar_no = aadhaar_no;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public double getTenure() {
		return tenure;
	}

	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
}
