package com.zeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
/*This is the main class for the springbootapplication 
*to make this application work we need to do run as java application this BootClass.java
*/
public class BootClass {
	public static void main(String[] args) {
		SpringApplication.run(BootClass.class, args);
	}

}
