package com.zeta.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.model.Loan;
import com.zeta.service.MyServiceImpl;
/*this main restcontroller is the first step of the layered 
 * 
 */
@RestController
public class MainController {
	@Autowired
	MyServiceImpl service;
	@RequestMapping("/loan/all")
	//this function will give the details about all the loan accounts
	public List<Loan> getLoanDetails() {
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Get loan details of all is invoked.");
		return service.getLoanDetails();
	};
	@RequestMapping(method = RequestMethod.GET,value="/loan/{loanno}")
	//this will give the loan account details of the given loan number
	public Loan getLoanById(@PathVariable int loanno) throws Exception{
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Get loan details by id is invoked.");
		Loan l = service.getLoanById(loanno);
		return l;
	};
	
	@PostMapping("/loan/add")
	//this will create an new loan account details into the table
	public Loan createNewLoan(@RequestBody Loan newloan) {
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Create new employee method is invoked.");
		return service.addNewLoan(newloan);
	};
	@PutMapping("/loan/update/{loanno}")
	//this will update the existing loan account
	public Loan updateLoan(@RequestBody Loan updateloan, @PathVariable int loanno) {
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Update employee details by id is invoked.");
		Loan l = service.getLoanById(loanno);
		updateloan.setLoan_no(loanno);
		return service.updateLoan(updateloan);
	};

	@DeleteMapping("/loan/delete/{loanno}")
	//this will delete the specific loan detail of particular id
	public void deleteLoanById(@PathVariable int loanno) throws Exception{
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Delete loan by id is invoked.");

		Loan emp =  service.getLoanById(loanno);

		service.deleteLoanById(loanno);
	};
	
	@DeleteMapping("/loan/deleteall")
	//this will delete all the accounts from the database
	public void deleteAll() {
		//Help.function(MainController.class).info(this.getClass().getSimpleName() + " - Delete all loans is invoked.");
		service.deleteAllLoans();
	};
}
